export const categories = [
    'smartphones',
    'laptops',
    'fragrances',
    'skincare',
    'groceries'
]