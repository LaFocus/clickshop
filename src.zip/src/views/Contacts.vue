<template>
    <div>

    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>
    div{
        height: 100vh;
    }
</style>