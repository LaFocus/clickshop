<template>
    <Intro />
    <MainContent /> 
</template>

<script setup>
import Intro from '@/components/Intro/Intro.vue'
import MainContent from '@/components/Main/MainContent.vue'



</script>

<style lang="scss" scoped>

</style>