<template>
    <main class="main">
        <div class="main__inner container">
            <MainGoods />
            <section class="main__inner__more">
                <div class="main__inner__more__item">
                    <h4>Christian Dior Sauvage Parfum</h4>
                    <p>In winter 2018, the world was presented a stunning new product from the famous perfume brand
                        Christian Dior - Sauvage Eau De Parfum</p>
                    <img src="@/assets/images/extra1.png" alt="">
                </div>
                <div class="main__inner__more__item">
                    <h4>iPhone 14</h4>
                    <p>The updated iPhone 14 is Apple's new smartphone, unveiled at the September 7, 2022 presentation. It
                        received a minimum of new changes, so it features an improved camera and new body colors. It also
                        has satellite communication for emergencies.</p>
                    <img src="@/assets/images/extra2.png" alt="">
                </div>
            </section>
        </div>
    </main>
</template>

<script setup>
import MainGoods from '@/components/Main/MainGoods.vue';




</script>

<style lang="scss" scoped></style>